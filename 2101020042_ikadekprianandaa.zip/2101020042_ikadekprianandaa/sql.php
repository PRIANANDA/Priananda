<?php

	$server		= "localhost"; 
	$user		= "root";
	$password   	= ""; 
	$database	     = "2101020042_ikadek_prianandaa"; 

	$con = mysqli_connect($server,$user,$password,$database);

?>